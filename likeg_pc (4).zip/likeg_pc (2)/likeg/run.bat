@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [1/2] Cai thu vien...
pip install -r requirements.txt
echo [2/2] Chay bot (tat cua so nay = tat bot)
python bot.py
pause
